"""
Shared simulation, mapping, and navigation settings.

Distances: meters
Time: seconds
Angles: radians unless explicitly named degrees

Edit the final destination in motor_physics.py's target dictionary.
"""

# ---------- Occupancy grid ----------

# Each grid cell is a cube with this edge length.
# Smaller cells resolve smaller gaps but increase memory/search cost.
CELL_SIZE = 0.25

# Automatically chosen map bounds include:
# - the actual starting position
# - the final destination
# - finite obstacle bounds
#
# Padding extends those bounds in all directions.
# Headroom adds additional space above the scene.
MAP_PADDING = 2.0
MAP_HEADROOM = 3.0

# Very wide, flat floor slabs remain obstacles but do not determine
# the horizontal size of the planning area.
LARGE_FLOOR_WIDTH = 30.0

# Explicit memory and search limits.
MAX_GRID_CELLS = 2_000_000
MAX_EXPANDED_NODES = 1_000_000

# ---------- Drone clearance ----------

# The drone's dimensions are estimated from its USD geometry.
# This margin is added around that envelope to allow clearance
# and some position-tracking error.
SAFETY_MARGIN = 0.25

# Used by both the controller and the drone-envelope estimate.
MAX_TILT_DEGREES = 10.0

# Your confirmed launch platform.
#
# The platform remains an obstacle in the occupancy grid.
# Only the initial upward departure may start inside its
# expanded clearance region.
LAUNCH_SUPPORT_ROOTS = (
    "/World/Cube",
)

# ---------- Waypoint following ----------

# A waypoint is reached when both position error and speed
# remain below these thresholds for WAYPOINT_DWELL seconds.
WAYPOINT_RADIUS = 0.08
WAYPOINT_SPEED = 0.12
WAYPOINT_DWELL = 0.25

# Desired speed limits used by the controller.
# These limit requested velocities, not measured velocities.
MAX_XY_SPEED = 2
MAX_Z_SPEED = 2

# Stop with a diagnostic error if a waypoint never settles.
WAYPOINT_TIMEOUT = 180.0

# ---------- Guided tracking of sloped segments ----------

# The controller's height loop responds much faster than its horizontal
# loop. Commanding only the far end of a segment that both climbs and
# translates would make the drone fly an L-shaped curve instead of the
# straight, collision-checked line.
#
# For such segments the follower slides intermediate targets along the
# line. A segment is flown point-to-point, as before, when even the
# worst L-shaped deviation would stay within TRACK_TOLERANCE.
#
# TRACK_TOLERANCE must remain below SAFETY_MARGIN. When the measured
# distance from the segment exceeds it, the targets stop leading and pull
# the drone back onto the line.
TRACK_TOLERANCE = 0.12

# How far ahead of the drone's progress along the segment the horizontal
# and height targets are placed, measured along the segment [m].
#
# TRACK_Z_LEAD = TRACK_XY_LEAD / 6 matches the controller's
# position-to-velocity ratios (horizontal 0.3/0.9, height 10/5).
# Both axes then ask for the same speed along the line, about
# TRACK_XY_LEAD / 3 m/s.
TRACK_XY_LEAD = 1.2
TRACK_Z_LEAD = 0.2

# ---------- USD paths ----------

DRONE_ROOT = "/World/iris"
BODY_PATH = "/World/iris/body"

# Exclude the drone, including its sensors, from obstacles.
# This does not exclude it from the drone-size calculation.
EXCLUDE_ROOTS = (
    DRONE_ROOT,
)

# Enabled collision geometry is mapped automatically.
#
# Add roots here only if you also want visual geometry without
# collision APIs to count as obstacles.
EXTRA_OBSTACLE_ROOTS = ()

# ---------- Propeller animation ----------

# Spin the propeller rigid bodies on their revolute joints so the motion
# is visible. Thrust, torque and yaw reaction are still applied to the
# body by the motor model, exactly as before; the spin is visual only.
PROPELLER_SPIN = True

# Revolute joints in motor order: joint i carries rotor i, matching
# rotor_positions and reaction_signs in motor_physics.py.
ROTOR_JOINT_PATHS = (
    "/World/iris/rotor0/joint0",
    "/World/iris/rotor1/joint1",
    "/World/iris/rotor2/joint2",
    "/World/iris/rotor3/joint3",
)

# Displayed speed = motor speed * scale.
#
# Real speeds (~820 rad/s at hover) turn more than once per 120 Hz frame,
# so they strobe on screen (look frozen or backwards). Spinning the rotor
# bodies that fast would also add gyroscopic torque the controller does
# not model. 0.05 gives about 40 rad/s at hover.
PROPELLER_SPIN_SCALE = 0.05

# Torque limit of each spin drive [N m]. Keeps the drive's reaction on the
# body small (controller torques are of order 0.05 N m) while still
# reaching the displayed speed in about 0.1 s.
PROPELLER_DRIVE_MAX_TORQUE = 0.05

# ---------- Sensors ----------

# Sensors provide optional logging.
# Navigation currently uses the USD map and simulator state.
ENABLE_SENSORS = True