"""Compare PD-only with PD+PPO on matching wind. Run with Isaac Sim's python.bat.

    C:\\isaacsim\\python.bat drone_code\\eval_ppo_hover.py --run-name run1

Each seed in ppo_config.EVAL_SEEDS gives one mean wind, gust sequence, and start
state, and both controllers fly every one of them. Writes per-seed rows and
paired statistics to runs/ppo_hover/<run-name>/eval_<wind>.json.

Metrics: position RMSE, maximum position error, failure rate, residual
magnitude, and motor saturation rate.
"""
import argparse
import json
from pathlib import Path

from isaacsim import SimulationApp


parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
parser.add_argument("--run-name", default="run1")
parser.add_argument("--model", default=None,
                    help="Model .zip. Default: the run's final_model.zip.")
parser.add_argument("--vecnormalize", default=None,
                    help="Statistics .pkl. Default: the run's final one.")
parser.add_argument("--wind-profile", default=None)
parser.add_argument("--episodes", type=int, default=None,
                    help="Use only the first N evaluation seeds.")
parser.add_argument("--gui", action="store_true")
parser.add_argument("--pd-only", action="store_true",
                    help="Skip PPO, for a baseline before any training.")
args = parser.parse_args()

# SimulationApp must exist before any omni, pxr, or isaacsim.core import.
simulation_app = SimulationApp({"headless": not args.gui})


def run_episode(env, seed, policy):
    """Fly one episode; policy(observation) returns a normalized action."""
    import numpy as np

    observation, reset_info = env.reset(seed=seed)

    errors = []
    residual_norms = []
    residual_physical = []
    saturated = 0
    physics_steps = 0
    total_cost = 0.0
    reason = None

    while True:
        observation, _, terminated, truncated, info = env.step(
            policy(observation)
        )

        errors.append(info["position_error"])
        residual_norms.append(info["residual_norm"])
        residual_physical.append(np.abs(info["residual"]))
        saturated += info["saturated_steps"]
        physics_steps += info["physics_steps"]
        total_cost += info["total_cost"]
        reason = info["failure_reason"]

        if terminated or truncated:
            break

    errors = np.array(errors, dtype=float)
    finite = errors[np.isfinite(errors)]
    mean_residual = np.mean(residual_physical, axis=0)

    return {
        "seed": int(seed),
        "wind_mean": [float(v) for v in reset_info["wind_mean"]],
        "wind_seed": reset_info["wind_seed"],
        "decisions": len(errors),
        "failed": reason is not None,
        "failure_reason": reason,
        "position_rmse": float(np.sqrt(np.mean(finite**2))),
        "max_position_error": float(np.max(finite)),
        "residual_norm": float(np.mean(residual_norms)),
        "mean_abs_thrust_residual": float(mean_residual[0]),
        "mean_abs_torque_residual": [float(v) for v in mean_residual[1:]],
        "saturation_rate": saturated / max(physics_steps, 1),
        "total_cost": float(total_cost),
    }


def summarize(rows):
    import numpy as np

    return {
        "episodes": len(rows),
        "position_rmse": float(np.mean([r["position_rmse"] for r in rows])),
        "max_position_error": float(
            np.max([r["max_position_error"] for r in rows])
        ),
        "mean_max_position_error": float(
            np.mean([r["max_position_error"] for r in rows])
        ),
        "failure_rate": float(np.mean([r["failed"] for r in rows])),
        "residual_norm": float(np.mean([r["residual_norm"] for r in rows])),
        "saturation_rate": float(
            np.mean([r["saturation_rate"] for r in rows])
        ),
        "total_cost": float(np.mean([r["total_cost"] for r in rows])),
    }


def main():
    import numpy as np

    import ppo_config

    from hover_env import make_hover_env

    project_dir = Path(__file__).resolve().parents[1]
    run_dir = project_dir / ppo_config.RUN_DIR / args.run_name

    wind_profile = args.wind_profile or ppo_config.DEFAULT_WIND_PROFILE

    seeds = ppo_config.EVAL_SEEDS

    if args.episodes is not None:
        seeds = seeds[:args.episodes]

    env = make_hover_env(
        simulation_app,
        wind_profile=wind_profile,
        render_sim=args.gui,
    )

    try:
        policies = {
            "pd_only": lambda observation: np.zeros(4, dtype=np.float32),
        }

        if not args.pd_only:
            from stable_baselines3 import PPO
            from stable_baselines3.common.vec_env import (
                DummyVecEnv,
                VecNormalize,
            )

            model_path = args.model or run_dir / "final_model.zip"
            stats_path = (
                args.vecnormalize or run_dir / "final_vecnormalize.pkl"
            )

            # The policy only understands observations scaled by the training
            # statistics. training=False freezes them.
            statistics = VecNormalize.load(
                str(stats_path),
                DummyVecEnv([lambda: env]),
            )
            statistics.training = False
            statistics.norm_reward = False

            model = PPO.load(str(model_path), device="cpu")

            def ppo_policy(observation):
                action, _ = model.predict(
                    statistics.normalize_obs(observation[None]),
                    deterministic=True,
                )
                return action[0]

            policies["pd_ppo"] = ppo_policy

        results = {}

        for name, policy in policies.items():
            results[name] = [
                run_episode(env, seed, policy)
                for seed in seeds
            ]

        # Both controllers must have flown the same realizations.
        for rows in results.values():
            for row, reference in zip(rows, results["pd_only"]):
                if (row["wind_mean"], row["wind_seed"]) != (
                    reference["wind_mean"], reference["wind_seed"]
                ):
                    raise RuntimeError(
                        f"Wind differs on seed {row['seed']}."
                    )

        summary = {
            name: summarize(rows)
            for name, rows in results.items()
        }

        print(f"\nWind profile: {wind_profile}; seeds: {len(seeds)}")
        print(
            f"{'':10}{'RMSE [m]':>10}{'max [m]':>10}{'fail':>8}"
            f"{'|a|':>8}{'sat':>8}{'cost':>9}"
        )

        for name, s in summary.items():
            print(
                f"{name:10}{s['position_rmse']:10.3f}"
                f"{s['max_position_error']:10.3f}"
                f"{s['failure_rate']:8.2f}{s['residual_norm']:8.3f}"
                f"{s['saturation_rate']:8.4f}{s['total_cost']:9.1f}"
            )

        if "pd_ppo" in results:
            better = sum(
                ppo["position_rmse"] < pd["position_rmse"]
                for ppo, pd in zip(results["pd_ppo"], results["pd_only"])
            )
            print(f"PD+PPO has lower RMSE on {better}/{len(seeds)} seeds.")

        run_dir.mkdir(parents=True, exist_ok=True)
        output = run_dir / f"eval_{wind_profile}.json"
        output.write_text(
            json.dumps(
                {"summary": summary, "episodes": results},
                indent=2,
            ),
            encoding="utf-8",
        )
        print(f"Saved {output}", flush=True)

    finally:
        env.close()


try:
    main()
finally:
    simulation_app.close()
