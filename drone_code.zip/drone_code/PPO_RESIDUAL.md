# PPO residual hover control

    state -> PD command + PPO correction -> motor mixer -> motor forces -> Isaac Sim

PPO adds bounded corrections to the PD thrust and torques so the drone holds a
fixed hover point in variable wind. One drone, one environment, standalone
Isaac Sim, Gymnasium, and Stable-Baselines3. No Isaac Lab.

## Install

Nothing to install. Isaac Sim 6.1's Python (3.12) already has everything:
gymnasium 1.4.0, stable-baselines3 2.9.0, torch 2.11.0, tensorboard 2.21.0.
To confirm:

    C:\isaacsim\python.bat -c "import gymnasium, stable_baselines3, torch, tensorboard; print(gymnasium.__version__, stable_baselines3.__version__, torch.__version__)"

If a package is ever missing, install it into Isaac's Python, not the system one:

    C:\isaacsim\python.bat -m pip install "stable-baselines3==2.9.0" "gymnasium==1.4.0" tensorboard

## Run

From `C:\drone_final_project1`. Run scripts one at a time.

    :: Unit tests, no SimulationApp (seconds). Run from drone_code.
    cd drone_code
    C:\isaacsim\python.bat -m unittest discover -s tests -p "test_*.py"
    cd ..

    :: Isaac smoke test (about 2 minutes). Do this before any long run.
    C:\isaacsim\python.bat drone_code\smoke_ppo_hover.py

    :: PD baseline, needs no model.
    C:\isaacsim\python.bat drone_code\eval_ppo_hover.py --run-name run1 --pd-only

    :: Train. --total-timesteps is required; 30 steps = 1 simulated second.
    C:\isaacsim\python.bat drone_code\train_ppo_hover.py --total-timesteps 500000 --run-name run1

    :: Resume. --total-timesteps is the total to reach, not extra steps.
    C:\isaacsim\python.bat drone_code\train_ppo_hover.py --total-timesteps 1000000 --run-name run1 --resume runs\ppo_hover\run1\checkpoints\hover_500000_steps.zip

    :: Compare PD-only with PD+PPO on the fixed seeds.
    C:\isaacsim\python.bat drone_code\eval_ppo_hover.py --run-name run1
    C:\isaacsim\python.bat drone_code\eval_ppo_hover.py --run-name run1 --wind-profile moderate

    :: Learning curves, in a second terminal.
    C:\isaacsim\python.bat -m tensorboard.main --logdir runs\ppo_hover

    :: Navigation demo, unchanged.
    C:\isaacsim\python.bat drone_code\motor_physics.py

Add `--gui` to the train, eval, or smoke scripts to watch; it is much slower.
Ctrl+C during training saves `interrupted_model.zip`, which `--resume` accepts.
Expect about 0.2 million steps per hour.

## Files

| File | Purpose |
| --- | --- |
| `drone_sim.py` | Backend moved out of `main()`: scene, World, views, motor mixer, COM compensation, wind wrench, forces, midair reset |
| `hover_task.py` | Observations, reward, failure, episode sampling. NumPy only |
| `hover_env.py` | Gymnasium environment |
| `ppo_config.py` | Reward weights, action limits, timing, failure limits, wind, PPO |
| `train_ppo_hover.py` | Training with checkpoints and resume |
| `eval_ppo_hover.py` | PD-only against PD+PPO on matching seeds |
| `smoke_ppo_hover.py` | Isaac Sim validation |
| `tests/test_hover_task.py` | Task logic against a stand-in simulator |

## What changed in existing files

- `motor_physics.py` now uses `DroneSim`; the navigation loop is the same.
- Motor parameters and rotor positions moved to `sim_config.py`, values
  unchanged. Physics parameters and controller gains are unchanged.
- `wind.py` gained `reset_episode()`. `reset()` behaves as before.
- `drone_diagnostics.py`: COM now comes from one view of all five bodies, and
  `cross()` replaces `np.cross`. This matches the per-body formula to 1e-6 m
  at the state tested and about doubles the step rate.

## Design choices

**Scene.** The demo scene loads once with the warehouse and launch pad disabled
in memory only, leaving the same drone and physics scene over open ground. Sensors
are off. Each episode starts airborne near (0, 0, 2) m.

**Reset.** `DroneSim.teleport` overwrites root pose and velocity, rotor angles,
rotor velocities, and spin targets without stopping physics. The whole
articulation goes through the `Articulation` view because the rotors are links
of it. Forces last one physics step in this PhysX API (measured), so they cannot
carry across an episode. `smoke_ppo_hover.py` confirms a violent episode leaves
the next one identical.

**Timing.** PD, mixer, motors, and wind run at 120 Hz. PPO picks an action every
4 steps (30 Hz); the residual is held between decisions.

**Residual limits.** ±1.5 N thrust, ±0.04 N m roll and pitch, ±0.02 N m yaw. These
come from what the PD loops need rather than motor authority, which is far larger:
PD has no integral term, so wind leaves a steady offset, and holding a lean against
attitude gain kp = 0.2 takes kp × angle. ±0.04 N m buys 11 degrees. All four at full
scale use about 0.6 N of a rotor's 3.1 N headroom, so at hover the residual alone
cannot saturate a rotor. The mixer's clipping and saturation flag are unchanged;
the rate is logged per step.

**Failure penalty.** With only costs, ending the episode looks attractive because
it stops future costs. Inside the failure limits every cost term is bounded, so a
flight costs at most c per decision and its discounted future cost is below
c / (1 - gamma). Failure charges exactly that amount, about 1980 with the current
settings, so crashing cannot beat continuing from any surviving state. It uses the
infinite sum rather than the steps left because PPO bootstraps the value at the
time limit. Rewards are not normalized by VecNormalize, which would clip this
penalty; a fixed `scale` of 0.1 keeps value targets moderate instead. Time limits
are truncation, with no penalty.

**Wind.** Each episode draws mean speed, direction, gust strength, and gust seed
from the env's seeded generator, in the `weak` profile by default. The policy never
sees wind. Gust noise does not depend on the drone's motion, so a seed gives the
same wind realization to both controllers, and `eval_ppo_hover.py` verifies the
match on every seed. Evaluation seeds are fixed in `ppo_config.EVAL_SEEDS`.

**Normalization.** Observations are scaled by fixed physical constants, then by
VecNormalize. Its statistics are saved with every checkpoint; evaluation loads them
frozen, and `--resume` continues updating them.

## Known limits

- PPO has not been shown to beat PD. A 30k-step run showed no improvement, and
  the 20-seed comparison has not been completed.
- The refactored demo differed from the original by up to 4.6 cm over a 15 s
  windy headless run. The original's run-to-run noise has not been measured, so
  whether this is noise or a real change is unknown.

- `isaacsim.core.api` and `isaacsim.core.prims` are deprecated since Isaac Sim 6.0.
  The demo already used them, so the backend stays on them.
- Rotors never reach `PROPELLER_SPIN_SCALE × motor speed`. `iris.usd` caps link
  angular speed at 100 rad/s, so they settle near 111 rad/s and their drives sit at
  the torque limit. This adds a 0.03-0.05 rad/s body-rate oscillation at hover, in
  the demo too. Training keeps it, so the policy trains on the demo's dynamics.
- The residual is trained for hover. It has not been tried inside the navigation
  demo.
