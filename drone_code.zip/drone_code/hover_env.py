"""Gymnasium environment: PD hover plus a bounded PPO residual.

    state -> PD command + held PPO residual -> motor mixer -> forces -> Isaac Sim

One drone in one environment. The env never starts or closes SimulationApp;
the launching script owns it, because it must exist before Isaac imports.
Build the sim with make_hover_env(), or pass any object with the same methods
as drone_sim.DroneSim (the unit tests use a small stand-in).
"""
from pathlib import Path

import gymnasium as gym
import numpy as np

import hover_task
import ppo_config
import sim_config

from controller import controller


class SimulationClosed(RuntimeError):
    """The Isaac Sim window was closed during an episode."""


class DroneHoverEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(
        self,
        sim,
        wind_profile=ppo_config.DEFAULT_WIND_PROFILE,
        render_sim=False,
        task=ppo_config.HOVER,
        residual_limits=ppo_config.RESIDUAL_LIMITS,
        reward=ppo_config.REWARD,
        failure=ppo_config.FAILURE,
        scales=ppo_config.OBSERVATION_SCALES,
        gamma=ppo_config.PPO["gamma"],
    ):
        super().__init__()

        self.sim = sim
        self.wind_profile = ppo_config.WIND_PROFILES[wind_profile]
        self.render_sim = bool(render_sim)
        self.task = task
        self.reward_weights = reward
        self.failure_limits = failure
        self.scales = scales

        self.target_position = np.asarray(
            task["target_position"], dtype=float
        )
        self.decimation = int(task["control_decimation"])
        self.max_decisions = int(task["max_decisions"])

        if self.target_position[2] <= failure["min_height"]:
            raise ValueError("Hover target is below the failure height.")

        self.residual_limits = hover_task.residual_limits_array(
            residual_limits
        )
        self.penalty = hover_task.failure_penalty(reward, failure, gamma)

        self.hover_thrust = sim.total_mass * hover_task.GRAVITY

        self.pd_target = sim.base_target()
        self.pd_target["xy"] = self.target_position[:2].copy()
        self.pd_target["height"] = float(self.target_position[2])

        # Motors spin at this speed in level hover; used to restart the rotors.
        self.hover_motor_speed = np.sqrt(
            self.hover_thrust / (4 * sim.motors.kf)
        )

        self.action_space = gym.spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(4,),
            dtype=np.float32,
        )

        self.observation_space = gym.spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(hover_task.OBSERVATION_SIZE,),
            dtype=np.float32,
        )

        self.previous_action = np.zeros(4, dtype=np.float32)
        self.decisions = 0
        self.wind_episode = None
        self.needs_reset = True

    def _pd_command(self, state):
        return np.array(
            controller(
                positions=state["position"],
                orientations=state["orientation"],
                velocities=state["linear_velocity"],
                angular_velocities=state["angular_velocity"],
                target=self.pd_target,
            ),
            dtype=float,
        )

    def _observation(self, state):
        return hover_task.build_observation(
            state,
            self.target_position,
            self._pd_command(state),
            self.hover_thrust,
            self.previous_action,
            self.scales,
        )

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        # Order matters for matching realizations: wind first, then the start.
        # Nothing here depends on the policy, so a given seed reproduces both.
        self.wind_episode = hover_task.sample_wind(
            self.np_random, self.wind_profile
        )
        initial = hover_task.sample_initial_state(self.np_random, self.task)

        self.previous_action = np.zeros(4, dtype=np.float32)
        self.decisions = 0
        self.needs_reset = False

        self.sim.wind.reset_episode(**self.wind_episode)
        self.sim.teleport(
            initial["position"],
            initial["orientation"],
            initial["linear_velocity"],
            initial["angular_velocity"],
            np.full(4, self.hover_motor_speed),
        )

        state = self.sim.read_drone_state()

        info = {
            "wind_mean": self.wind_episode["mean_wind"].copy(),
            "wind_gust_scale": self.wind_episode["gust_scale"],
            "wind_seed": self.wind_episode["seed"],
        }

        return self._observation(state), info

    def step(self, action):
        if self.needs_reset:
            raise RuntimeError("Call reset() before step().")

        action = np.asarray(action, dtype=np.float32).reshape(4)

        if not np.all(np.isfinite(action)):
            raise ValueError(f"Invalid action: {action}")

        action = np.clip(action, -1.0, 1.0)

        if not self.sim.is_running():
            raise SimulationClosed("Simulation closed during an episode.")

        # Held for every physics step of this decision. PD, motors, and wind
        # are all recomputed from the fresh state inside the loop.
        residual = action.astype(float) * self.residual_limits

        saturated_steps = 0
        simulated_steps = 0
        state = self.sim.read_drone_state()

        for substep in range(self.decimation):
            if hover_task.failure_reason(
                state, self.target_position, self.failure_limits
            ) == "invalid_state":
                break

            command = self._pd_command(state) + residual

            _, saturated, _, _ = self.sim.step_command(
                state,
                *command,
                render=(
                    self.render_sim
                    and substep == self.decimation - 1
                ),
            )

            saturated_steps += int(saturated)
            simulated_steps += 1
            state = self.sim.read_drone_state()

        self.decisions += 1

        reason = hover_task.failure_reason(
            state, self.target_position, self.failure_limits
        )

        terminated = reason is not None
        truncated = not terminated and self.decisions >= self.max_decisions

        if reason == "invalid_state":
            # Non-finite values must not reach the reward or the policy.
            costs = {name: 0.0 for name in (
                "position", "speed", "attitude",
                "angular_rate", "action", "action_rate",
            )}
            position_error = float("nan")
            observation = np.zeros(
                hover_task.OBSERVATION_SIZE, dtype=np.float32
            )
        else:
            costs = hover_task.step_costs(
                state,
                self.target_position,
                action,
                self.previous_action,
                self.reward_weights,
            )
            position_error = float(np.linalg.norm(
                self.target_position - state["position"]
            ))

        total_cost = sum(costs.values())
        penalty = self.penalty if terminated else 0.0
        reward = -self.reward_weights["scale"] * (total_cost + penalty)

        self.previous_action = action.copy()

        if reason != "invalid_state":
            observation = self._observation(state)

        self.needs_reset = terminated or truncated

        info = {
            "costs": costs,
            "total_cost": total_cost,
            "failure_penalty": penalty,
            "failure_reason": reason,
            "position_error": position_error,
            "residual_norm": float(np.linalg.norm(action)),
            "residual": residual.copy(),
            "saturated_steps": saturated_steps,
            "physics_steps": simulated_steps,
        }

        return observation, float(reward), terminated, truncated, info

    def close(self):
        self.sim.close()


def make_hover_env(
    simulation_app,
    wind_profile=ppo_config.DEFAULT_WIND_PROFILE,
    render_sim=False,
    log=print,
):
    """Load the open hover scene once and wrap it in a DroneHoverEnv.

    Call only after SimulationApp has started.
    """
    from drone_sim import DroneSim

    project_dir = Path(__file__).resolve().parents[1]
    profile = ppo_config.WIND_PROFILES[wind_profile]

    # Episode wind comes from the profile; the rest is the demo's model.
    wind_config = dict(sim_config.WIND)
    wind_config.update(
        enabled=profile["enabled"],
        gust_std=profile["gust_std"],
        local_gust_std=profile["local_gust_std"],
    )

    sim = DroneSim(
        simulation_app,
        project_dir / ppo_config.SCENE,
        log=log,
        wind_config=wind_config,
        deactivate_prims=ppo_config.DEACTIVATE_PRIMS,
    )

    sim.world.play()

    return DroneHoverEnv(
        sim,
        wind_profile=wind_profile,
        render_sim=render_sim,
    )
