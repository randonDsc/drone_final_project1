"""Train PPO residual hover. Run with Isaac Sim's python.bat.

    C:\\isaacsim\\python.bat drone_code\\train_ppo_hover.py --total-timesteps 200000

--total-timesteps is required, so nothing long starts by accident. On --resume
it is the total to reach, counting the steps already in the checkpoint.

Saves under runs/ppo_hover/<run-name>/: checkpoints, TensorBoard logs, and
final_model.zip with final_vecnormalize.pkl.
"""
import argparse
from pathlib import Path

from isaacsim import SimulationApp


parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
parser.add_argument("--total-timesteps", type=int, required=True,
                    help="PPO decisions to reach (30 per simulated second).")
parser.add_argument("--run-name", default="run1")
parser.add_argument("--resume", default=None,
                    help="Checkpoint .zip to continue from.")
parser.add_argument("--wind-profile", default=None)
parser.add_argument("--seed", type=int, default=None)
parser.add_argument("--checkpoint-interval", type=int, default=None)
parser.add_argument("--gui", action="store_true",
                    help="Show the Isaac Sim window (slower).")
args = parser.parse_args()

# SimulationApp must exist before any omni, pxr, or isaacsim.core import.
simulation_app = SimulationApp({"headless": not args.gui})


def vecnormalize_path_for(checkpoint):
    """<prefix>_<N>_steps.zip -> <prefix>_vecnormalize_<N>_steps.pkl."""
    checkpoint = Path(checkpoint)
    name = checkpoint.stem

    if name == "final_model" or name == "interrupted_model":
        prefix = name.removesuffix("_model")
        return checkpoint.with_name(f"{prefix}_vecnormalize.pkl")

    head, steps, tail = name.rsplit("_", 2)
    return checkpoint.with_name(f"{head}_vecnormalize_{steps}_{tail}.pkl")


def main():
    # Deferred, like the demo's imports, until SimulationApp is running.
    import numpy as np

    from stable_baselines3 import PPO
    from stable_baselines3.common.callbacks import (
        BaseCallback,
        CheckpointCallback,
    )
    from stable_baselines3.common.monitor import Monitor
    from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

    import ppo_config

    from hover_env import SimulationClosed, make_hover_env

    class HoverMetricsCallback(BaseCallback):
        """Send reward components and failure stats to TensorBoard."""

        def _on_step(self):
            for info, done in zip(self.locals["infos"], self.locals["dones"]):
                for name, value in info["costs"].items():
                    self.logger.record_mean(f"cost/{name}", value)

                self.logger.record_mean(
                    "hover/position_error", info["position_error"]
                )
                self.logger.record_mean(
                    "hover/residual_norm", info["residual_norm"]
                )
                self.logger.record_mean(
                    "hover/saturation_rate",
                    info["saturated_steps"]
                    / max(info["physics_steps"], 1),
                )

                if done:
                    self.logger.record_mean(
                        "hover/failure_rate",
                        float(info["failure_reason"] is not None),
                    )

            return True

    training = ppo_config.TRAINING
    wind_profile = args.wind_profile or ppo_config.DEFAULT_WIND_PROFILE
    seed = training["seed"] if args.seed is None else args.seed

    project_dir = Path(__file__).resolve().parents[1]
    run_dir = project_dir / ppo_config.RUN_DIR / args.run_name
    checkpoint_dir = run_dir / "checkpoints"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    env = make_hover_env(
        simulation_app,
        wind_profile=wind_profile,
        render_sim=args.gui,
    )

    # One env, so one DummyVecEnv slot. SB3's Monitor adds ep_rew_mean.
    venv = DummyVecEnv([lambda: Monitor(env)])

    try:
        if args.resume:
            checkpoint = Path(args.resume)
            venv = VecNormalize.load(
                str(vecnormalize_path_for(checkpoint)), venv
            )
            venv.training = True

            model = PPO.load(
                str(checkpoint),
                env=venv,
                device=ppo_config.PPO["device"],
            )
            print(
                f"Resumed {checkpoint} at {model.num_timesteps} steps.",
                flush=True,
            )
        else:
            # Rewards are not normalized: VecNormalize would clip the failure
            # penalty, and hover_task.failure_penalty relies on its full size.
            venv = VecNormalize(
                venv,
                norm_obs=True,
                norm_reward=False,
                clip_obs=training["observation_clip"],
            )

            model = PPO(
                "MlpPolicy",
                venv,
                seed=seed,
                verbose=1,
                tensorboard_log=str(run_dir / "tensorboard"),
                **ppo_config.PPO,
            )

        remaining = args.total_timesteps - model.num_timesteps

        if remaining <= 0:
            print(
                f"Already at {model.num_timesteps} steps; nothing to do.",
                flush=True,
            )
            return

        interval = (
            training["checkpoint_interval"]
            if args.checkpoint_interval is None
            else args.checkpoint_interval
        )

        callbacks = [
            HoverMetricsCallback(),
            CheckpointCallback(
                save_freq=interval,
                save_path=str(checkpoint_dir),
                name_prefix="hover",
                save_vecnormalize=True,
            ),
        ]

        try:
            model.learn(
                total_timesteps=remaining,
                callback=callbacks,
                reset_num_timesteps=False,
                tb_log_name="ppo",
            )

            model.save(str(run_dir / "final_model"))
            venv.save(str(run_dir / "final_vecnormalize.pkl"))
            print(f"Saved final model in {run_dir}", flush=True)

        except (KeyboardInterrupt, SimulationClosed) as stop:
            # Keep what was learned; resume with --resume interrupted_model.zip.
            model.save(str(run_dir / "interrupted_model"))
            venv.save(str(run_dir / "interrupted_vecnormalize.pkl"))
            print(
                f"Stopped ({type(stop).__name__}); saved in {run_dir}",
                flush=True,
            )

    finally:
        venv.close()


try:
    main()
finally:
    simulation_app.close()
